//
//  ViewController.swift
//  GoingGreen
//
//  Created by Riya Singh on 3/23/19.
//  Copyright © 2019 Makers. All rights reserved.
//

import UIKit

class ViewController: UIViewController {


    @IBAction func action(_ sender: Any) {
        performSegue(withIdentifier: "segue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}


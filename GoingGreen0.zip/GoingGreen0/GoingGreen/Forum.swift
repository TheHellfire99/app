//
//  Forum.swift
//  GoingGreen
//
//  Created by Riya Singh on 3/24/19.
//  Copyright © 2019 Makers. All rights reserved.
//

import UIKit

class Forum: UIViewController {

    @IBAction func action(_ sender: Any) { performSegue(withIdentifier: "forum-home", sender: self)
    }
    
    @IBAction func action2(_ sender: Any) { performSegue(withIdentifier: "forum-recycling", sender: self)
    }
    
    @IBAction func action3(_ sender: Any) { performSegue(withIdentifier: "forum-service", sender: self)
    }
    
    @IBAction func action4(_ sender: Any) { performSegue(withIdentifier: "local", sender: self)
    }
    
    @IBAction func action6(_ sender: Any) { performSegue(withIdentifier: "education", sender: self)
    }
    
    @IBAction func action5(_ sender: Any) { performSegue(withIdentifier: "development", sender: self)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

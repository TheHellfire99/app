//
//  Services.swift
//  GoingGreen
//
//  Created by Riya Singh on 3/24/19.
//  Copyright © 2019 Makers. All rights reserved.
//

import UIKit

class Services: UIViewController {
    var x = 0

    @IBAction func action(_ sender: Any) { performSegue(withIdentifier: "service-home", sender: self)
    }
    
    @IBAction func action2(_ sender: Any) { performSegue(withIdentifier: "service-recycling", sender: self)
    }
    
    @IBAction func action3(_ sender: Any) { performSegue(withIdentifier: "service-forum", sender: self)
    }
    
    @IBAction func action4(_ sender: Any) {
        guard let url = URL(string: "https://www.google.com/search?rlz=1C5CHFA_enUS811US811&ei=eIuXXJq-Forw-gSkipGQBg&q=south+bay+environmental+service&oq=south+bay+environmental+service&gs_l=psy-ab.3..0.73201.73586..73749...0.0..0.63.307.5......0....1..gws-wiz.......0i71j0i7i30j0i13i30.NoH2h3bjLsI") else { return }
        UIApplication.shared.open(url)
    }
    
    @IBAction func action5(_ sender: Any) {
        guard let url = URL(string: "https://www.google.com/search?rlz=1C5CHFA_enUS811US811&ei=Q4uXXIDfCI7m-wT-7JrICQ&q=north+bay+environmental+service&oq=north+bay+environmental+service&gs_l=psy-ab.3..0i22i30l2.630.7854..7959...0.0..0.93.2047.31......0....1..gws-wiz.......35i39j0i67j0j0i131j0i131i67j0i22i10i30j33i22i29i30.a-1v4pyrDvo") else { return }
        UIApplication.shared.open(url)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
